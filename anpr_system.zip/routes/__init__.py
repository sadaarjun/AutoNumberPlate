# Routes package initialization
# This file is required to make the 'routes' directory a Python package
# so that its modules can be imported elsewhere in the application.
